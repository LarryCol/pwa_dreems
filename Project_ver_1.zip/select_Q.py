import random
import json


class QSelect:

    def __init__(self):
        self.subj = input('enter subject ')
        self.cla = input('enter class ')
        self.cha = input('enter chapter name ')
        self.mark1 = int(input('enter num of 1 mark Q needed '))
        self.mark2 = int(input('enter num of 2 marks Q needed '))
        self.mark3 = int(input('enter num of 5 marks Q needed '))
        self.rate = int(input('enter difficulty rating '))

    def q_print(self):
        with open(self.subj) as f:
            self.data2 = json.load(f)
        self.qset = self.data2[self.cla][self.cha]
        self.a, self.b, self.c = 0, 0, 0
        self.qu1 = set()
        self.qu2 = set()
        self.qu3 = set()
        f1 = open("questions.txt", "w")

        f1.write('One mark Q\n')
        while self.a < self.mark1:
            self.d = random.randint(0, len(self.qset) - 1)
            self.y = self.qset[self.d]
            if self.y['marks'] == 1 and self.y['rate'] == self.rate:
                if self.y['question'] in self.qu1:
                    continue
                else:
                    print(self.y['question'])
                    self.a += 1
                    f1.write(self.y['question'] + '\n')
                self.qu1.add(self.y['question'])
        f1.write('\n')

        print('\n')
        f1.write('Two marks Q\n')

        while self.b < self.mark2:
            self.e = random.randint(0, len(self.qset) - 1)
            self.u = self.qset[self.e]
            if self.u['marks'] == 2 and self.u['rate'] == self.rate:
                if self.u['question'] not in self.qu2:
                    print(self.u['question'])
                    self.b += 1
                    f1.write(self.u['question'] + '\n')
                else:
                    continue
                self.qu2.add(self.u['question'])
        f1.write('\n')

        print('\n')
        f1.write('Five marks Q\n')

        while self.c < self.mark3:
            self.f = random.randint(0, len(self.qset) - 1)
            self.v = self.qset[self.f]
            if self.v['marks'] == 5 and self.v['rate'] == self.rate:
                if self.v['question'] in self.qu3:  # checks if the question is in set to avoid question repeating
                    continue
                else:
                    print(self.v['question'])
                    self.c += 1
                    f1.write(self.v['question'] + '\n')
                self.qu3.add(self.v['question'])  # adds the question to a set
        f1.close()

# q3 = QSelect()
# q3.q_print()
