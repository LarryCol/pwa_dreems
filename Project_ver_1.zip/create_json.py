import json


class CreateJson:
    def __init__(self):
        self.sub = input('enter subject name ')
        self.cla = int(input('enter number of classes '))
        self.ncha = int(input('enter number of chapters '))

    def py_obj(self):
        # self.dict1 = {}
        l1 = []
        l2 = []
        for i in range(1, self.ncha + 1):
            l1.append('chapter{}'.format(i))
        self.dict1 = dict.fromkeys(l1, [])
        print(self.dict1)
        for j in range(1, self.cla + 1):
            l2.append('class{}'.format(j))
        self.dict2 = dict.fromkeys(l2, self.dict1)
        print(self.dict2)

    def to_file(self):
        with open(self.sub, 'w')as f1:
            json.dump(self.dict2, f1, indent=3)

# q1 = CreateJson()
# q1.py_obj()
# q1.to_file()
