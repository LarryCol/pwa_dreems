import tkinter
from add_data import AddQ
from select_Q import *
from multi_chapter import MultiChapter
from create_json import CreateJson

window = tkinter.Tk()
window.geometry("250x250")
window.title("Welcome to Q_Set")


def select_q():
    q1 = QSelect()
    q1.q_print()


def add_q():
    q2 = AddQ()
    q2.insert_q()


def multi_chapt():
    q3 = MultiChapter()
    q3.all_chapter()


def create_qset():
    q4 = CreateJson()
    q4.py_obj()
    q4.to_file()


bt1 = tkinter.Button(window, text="click to select Questions", command=select_q)
bt1.grid(column=1, row=1)

bt2 = tkinter.Button(window, text="click to add Q", command=add_q)
bt2.grid(column=1, row=2)

bt3 = tkinter.Button(window, text="Q from all chapters", command=multi_chapt)
bt3.grid(column=1, row=3)

bt4 = tkinter.Button(window, text="create a new question set file", command=create_qset)
bt4.grid(column=1, row=4)

window.mainloop()
