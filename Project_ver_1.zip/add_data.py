import json


class AddQ:

    def __init__(self):
        self.sub = input('enter subject ')
        self.cl = input('enter class ')
        self.c = input('enter chapter ')
        self.q = input('enter your question ')
        self.m = int(input('enter the marks '))
        self.r = int(input('enter the difficulty rating '))
        self.k = input('enter a key word')

    def create_dict(self):
        self.d1 = dict(question=self.q, marks=self.m, rate=self.r, keywords=self.k)
        print(self.d1)

    def insert_q(self):
        with open(QBank/self.sub) as f1:
            data1 = json.load(f1)

        self.d2 = data1[self.cl]
        self.l1 = data1[self.cl][self.c]

        self.l1.append(self.d1)
        del self.d2[self.c]
        self.d2.update({self.c: self.l1})
        del data1[self.cl]
        data1.update({self.cl: self.d2})

        with open(QBank/self.sub, 'w') as f2:
            json.dump(data1, f2, indent=4)


# new_q = AddQ()
# new_q.create_dict()
# new_q.insert_q()
