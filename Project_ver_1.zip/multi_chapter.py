import json
import random



class MultiChapter:


    def __init__(self):
        # self.num1 = None
        self.num5 = int(input('enter number of five marks questions needed '))
        self.num2 = int(input('enter number of two marks questions needed '))
        self.num1 = int(input('enter number of one mark questions needed '))
        self.rate = int(input('enter difficulty rating '))
        self.subj = input('enter subject ')
        self.cla = input('enter class ')
        # self.cha = int(input('enter number of chapters needed '))
        # if self.cha == 0:
        #     self.all_cha = True


    def all_chapter(self):
        with open(self.subj) as f2:
            self.data1 = json.load(f2)
        self.one ,self.two, self.five = 0, 0, 0
        self.qu1 = set()
        self.qu2 = set()
        self.qu3 = set()
        f3 = open("all_chapters.txt", "w")
        self.dict1 = self.data1[self.cla]
        self.l1 = list(self.dict1)
        f3.write('One mark Q\n')
        while self.one < self.num1:
            self.rand_value = random.randint(0, len(self.l1) - 1)
            self.dict2 = self.dict1[self.l1[self.rand_value]]
            self.d = random.randint(0, len(self.l1) - 1)
            self.y = self.dict2[self.d]
            if self.y['marks'] == 1 and self.y['rate'] == self.rate:
                if self.y['question'] in self.qu1:
                    continue
                else:
                    print(self.y['question'])
                    self.one += 1
                    f3.write(self.y['question'] + '\n')
                self.qu1.add(self.y['question'])
        f3.write('\n')
        print('\n')
        f3.write('Two marks Q\n')

        while self.two < self.num2:
            self.rand_value2 = random.randint(0, len(self.l1) - 1)
            self.dict22 = self.dict1[self.l1[self.rand_value2]]
            self.d1 = random.randint(0, len(self.dict22) - 1)
            self.y1 = self.dict22[self.d1]
            # print(self.d1,'\n')
            # print(self.y1, '\n')
            # print(self.dict22)
            # break
            if self.y1['marks'] == 2 and self.y1['rate'] == self.rate:
                if self.y1['question'] in self.qu2:
                    continue
                else:
                    print(self.y1['question'])
                    self.two += 1
                    f3.write(self.y1['question'] + '\n')
                self.qu2.add(self.y1['question'])
        f3.write('\n')
        print('\n')
        f3.write('Five marks Q\n')

        while self.five < self.num5:
            self.rand_value5 = random.randint(0, len(self.l1) - 1)
            self.list5 = self.dict1[self.l1[self.rand_value5]]
            self.d5 = random.randint(0, len(self.list5) - 1)
            self.y5 = self.list5[self.d5]
            # print(self.list5, '\n')
            # print(self.d5, '\n')
            # print(self.y5)
            # break
            if self.y5['marks'] == 5 and self.y5['rate'] == self.rate:
                if self.y5['question'] in self.qu3:
                    continue
                else:
                    print(self.y5['question'])
                    self.five += 1
                    f3.write(self.y5['question'] + '\n')
                self.qu3.add(self.y5['question'])
        f3.close()


# q1 = MultiChapter()
# if q1.all_cha:
#     q1.all_chapter()




